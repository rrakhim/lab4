
"use strict";

let accelerometr = require('./accelerometr.js');
let contact = require('./contact.js');
let coord = require('./coord.js');
let fsrInput = require('./fsrInput.js');
let tactile = require('./tactile.js');
let state = require('./state.js');
let newtactile = require('./newtactile.js');
let rigid = require('./rigid.js');

module.exports = {
  accelerometr: accelerometr,
  contact: contact,
  coord: coord,
  fsrInput: fsrInput,
  tactile: tactile,
  state: state,
  newtactile: newtactile,
  rigid: rigid,
};
