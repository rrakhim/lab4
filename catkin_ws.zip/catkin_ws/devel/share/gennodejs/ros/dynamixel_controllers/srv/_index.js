
"use strict";

let SetSpeed = require('./SetSpeed.js')
let TorqueEnable = require('./TorqueEnable.js')
let SetCompliancePunch = require('./SetCompliancePunch.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')
let SetComplianceMargin = require('./SetComplianceMargin.js')
let StopController = require('./StopController.js')
let StartController = require('./StartController.js')
let RestartController = require('./RestartController.js')
let SetTorqueLimit = require('./SetTorqueLimit.js')

module.exports = {
  SetSpeed: SetSpeed,
  TorqueEnable: TorqueEnable,
  SetCompliancePunch: SetCompliancePunch,
  SetComplianceSlope: SetComplianceSlope,
  SetComplianceMargin: SetComplianceMargin,
  StopController: StopController,
  StartController: StartController,
  RestartController: RestartController,
  SetTorqueLimit: SetTorqueLimit,
};
