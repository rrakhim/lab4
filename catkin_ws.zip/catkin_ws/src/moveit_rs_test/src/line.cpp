#include <moveit/move_group_interface/move_group.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit_msgs/DisplayRobotState.h>
#include <moveit_msgs/DisplayTrajectory.h>
#include <moveit_msgs/AttachedCollisionObject.h>
#include <moveit_msgs/CollisionObject.h>
#include <moveit_visual_tools/moveit_visual_tools.h>

int main(int argc, char **argv)
{
  ros::init(argc, argv, "move_group_interface_tutorial");
  ros::NodeHandle node_handle;
  ros::AsyncSpinner spinner(0);
  spinner.start();
  static const std::string PLANNING_GROUP = "arm_group"; // Group of m2m and joints 2, 4, 6.
  moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP);

  const robot_state::JointModelGroup *joint_model_group =
      move_group.getCurrentState()->getJointModelGroup(PLANNING_GROUP);
  geometry_msgs::PoseStamped current_pose; // Pose for tracking current position.
  geometry_msgs::PoseStamped temp_pose; // Temporary pose for keeping line straight.
  geometry_msgs::PoseStamped end_pose; // Pose for the ending point of the line.
  current_pose = move_group.getCurrentPose();// Setting default position to the current pose.
  temp_pose = current_pose; //Setting same position to the temporary pose
  end_pose = current_pose; // and to the ending pose.
  end_pose.pose.position.x = end_pose.pose.position.x - 1.4; // Then setting the X-coordinate of the line's end.
  ros::Rate loop_rate(100);

  /*
      Simply changing X coordinate of the end point will move it, but not by straight line.
      Calculated trajectory will be like quarter of a circle.
      I used many small lines that have trajectory of a straight line.
      Together they form perfect line, though it is very time-consuming. */

  while (ros::ok()){
    temp_pose.pose.position.x = current_pose.pose.position.x - 0.1; // Moves by X-axis for small amount each iteration
    temp_pose.pose.position.y = current_pose.pose.position.y; // while keeping Y-coordinate the same as before.
    move_group.setApproximateJointValueTarget(temp_pose);
    move_group.move();
    current_pose = move_group.getCurrentPose();
    if (abs(current_pose.pose.position.x - end_pose.pose.position.x) < 0.01){ // Once it reaches ending poes, loop breaks.
      break;
    }
    loop_rate.sleep();
  }


  ROS_INFO("Done");
  ros::shutdown();
  return 0;
}